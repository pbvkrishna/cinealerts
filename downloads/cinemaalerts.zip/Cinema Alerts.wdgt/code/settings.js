
	var DEBUGMODE = 0;

function debug_alert(str)
{
    if(DEBUGMODE)
        alert(str);    
}

function debug_msg(str)
{
    if(DEBUGMODE && window.PluginObject)
    {
        PluginObject.Log(str);
    }
}
function alert(str)
{
    if(DEBUGMODE && window.PluginObject)
    {
        PluginObject.Log(str);
    }
}
function GadgetSettings()
{	
	this.server  = "http://192.168.0.193/";
	this.name  = "test";
	this.id = "0";
	this.containerWidth  = 300;
	this.containerHeight  = 300;
	this.widgetWidth = 0;
	this.widgetHeight = 300;
	this.refreshTime = 0;
	this.caption  = "Testing gadget";
	this.contentType = "text";
	this.content = "<html>\n\t<head>\n\t\t<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">\n\t</head>\n\t<body>\n\t\t<b>test</b>\n\t</body>\n</html>";
	this.version = "1.0.0.1";
	this.lastUpdateTime = 0;
	this.guid = 0;
	this.xmlPath = "../";
}
GadgetSettings.prototype.minWidth = 205;
GadgetSettings.prototype.minHeight = 175;
GadgetSettings.prototype.minTableWidth = 170;
GadgetSettings.prototype.minTableHeight = 170;
GadgetSettings.prototype.hBorder = 19;
GadgetSettings.prototype.vBorder = 40;


//-------------------------------------------------------------------------------------------------------------
GadgetSettings.prototype.saveContent = function(fileName)
{
	//create content.html file
	var writer = new ActiveXObject("Scripting.FileSystemObject");
	var file = writer.CreateTextFile(System.Gadget.path + "\\" + fileName, true, true);
	file.WriteLine("<html>\n\t<head>\n\t\t<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />\n\t</head>\n\t<body style=\"background-color: transparent; padding:0px; margin: 0px;\">\n\t\t"+
					this.content + "\n\t</body>\n</html>");
	file.Close();
};
	
	
//-------------------------------------------------------------------------------------------------------------
GadgetSettings.prototype.load = function()
{
	try
	{
		//load xml document from a file
		var xmlDoc = new ActiveXObject("Microsoft.XMLDOM"); 
		xmlDoc.async = "false";
    	xmlDoc.load(this.xmlPath + "settings.xml");


		if(xmlDoc.parseError.errorCode  === 0) 
		{
			//parse xml
			var desktopContainer = xmlDoc.getElementsByTagName("DesktopContainer")[0];
			this.server = desktopContainer.getAttribute("server");
			this.name = desktopContainer.getAttribute("name");
			this.id = desktopContainer.getAttribute("id");

			
			var mainWindow = xmlDoc.getElementsByTagName("MainWindow")[0];
			
			//determine width and height
			this.widgetWidth = parseInt(mainWindow.getAttribute("width"));
			this.widgetHeight = parseInt(mainWindow.getAttribute("height"));
			
			//this.containerWidth = Math.max(this.widgetWidth, this.minWidth)/* + this.hBorder*/;
			//this.containerHeight = this.widgetHeight /*+ this.vBorder*/;
			

						
			//determine caption
			this.caption = mainWindow.getAttribute("caption");
			
			
			var widget = xmlDoc.getElementsByTagName("Widget")[0];
			this.contentType = widget.getAttribute("contentType");
			this.refreshTime = widget.getAttribute("refreshTime");
			if(this.refreshTime) this.refreshTime *= 1000*60; //from minutes to miliseconds
			
			
			//validate content type
			if(this.contentType != "text" && this.contentType != "url") this.contentType = "text";
			
			this.content = widget.childNodes[0].nodeValue;
			
			var fso = new ActiveXObject("Scripting.FileSystemObject");
			if(fso.FileExists(System.Gadget.path + "\\fistrun.txt"))
			{
				var f = fso.OpenTextFile(System.Gadget.path + "\\fistrun.txt", 1);
				this.guid = f.ReadLine();
				f.Close();
				
				//bad guid - delete file
				if(this.guid.length < 40) 
				{
					fso.DeleteFile(System.Gadget.path + "\\fistrun.txt", true);
				}		
				else
				{
					this.guid.trim();
				}
			}
		}
	}
	catch(e){debug_msg("GadgetSettings::load ERROR:\n"+e.message);}
};