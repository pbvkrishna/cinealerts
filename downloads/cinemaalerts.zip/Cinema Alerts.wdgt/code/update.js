function UpdateManager(settings)
{
	this.settingsObject = settings;
	
	this.fileName = "update.xml";
	
	this.serverTimeout = 0;
	this.serverTimeStamp = 0;
	this.localTimeStamp = 0;
	
	this.currentVersion = null;
	this.updatePeriod = 3600000;
	
	this.updateUrls = new Array();
	
	this.tempFolderPath = getTempFolderPath();
	
	this.onUpdateComplete = 0;
	
	//initialization
	this.loadFromFile();
	this.checkForUpdates();	
}


//-------------------------------------------------------------------------------------------------------------------
UpdateManager.prototype.loadFromFile = function()
{
	try
	{
		//load xml document from a file
		var xmlDoc = new ActiveXObject("Microsoft.XMLDOM"); 
		xmlDoc.async = "false";
		xmlDoc.load(this.settingsObject.xmlPath + this.fileName);

		if(xmlDoc.parseError.errorCode  === 0) 
		{
			//load local time stamp
			var localStamp = xmlDoc.getElementsByTagName("localtimestamp")[0];
			var t;
			if(localStamp !== null)
			{
				t = localStamp.getAttribute("t");
				this.localTimeStamp = t;
			}
			
			
			//load server timestamp
			var serverStamp = xmlDoc.getElementsByTagName("servertimestamp")[0];
			if(serverStamp !== null)
			{
				t = serverStamp.getAttribute("t");
				this.serverTimeStamp = t;
			}			
		}
		
		
		//load version from gadget.xml
		xmlDoc.load(this.settingsObject.xmlPath + "gadget.xml");
		if(xmlDoc.parseError.errorCode  === 0) 
		{
			var ver = xmlDoc.getElementsByTagName("version")[0].childNodes[0].nodeValue;
			if(this.currentVersion !== null && ver != this.currentVersion)  
			{ 
				setTimeout(function(){System.Gadget.document.parentWindow.location.reload();}, 1000); 
			}
			this.currentVersion = ver;
			this.settingsObject.version = ver;
		}
		else
		{
			this.currentVersion = System.Gadget.version;
		}
	}
	catch(e)
	{
		alert(e.message);
	}
};


//-------------------------------------------------------------------------------------------------------------------
UpdateManager.prototype.saveToFile = function()
{
	//create xml output string
	var xml =	"<?xml version='1.0' encoding='utf-8'?>\n" +
				"<update>\n" + 
				"<localtimestamp t='" + this.localTimeStamp + "'/>\n" + 
				"<servertimestamp t='" + this.serverTimeStamp + "'/>\n" + 
				"</update>";

	
	//save stamps to file
	var writer = new ActiveXObject("Scripting.FileSystemObject");	
	var file = writer.OpenTextFile(System.Gadget.path + "\\" + this.fileName, ForWriting, true);
	file.WriteLine(xml);		
	file.Close();
};


//-------------------------------------------------------------------------------------------------------------------
UpdateManager.prototype.downLoadUpdateFiles = function()
{
	//clear temp folder
	var fileMan = new ActiveXObject("Scripting.FileSystemObject");	

	try
	{
		if(fileMan.FolderExists(this.tempFolderPath))
		{	
			var f = fileMan.GetFolder(this.tempFolderPath);
			f.Delete();
			fileMan.CreateFolder(this.tempFolderPath);
		}
	}
	catch(e) {alert(e.message);}
	
	//flags array for checking update complete
	var updateDone = new Array();
	for(var ind=0; ind<this.updateUrls.length; ind++)
	{
		updateDone[ind] = false;
	}
	
	
	var self = this;
	for(var i=0; i<this.updateUrls.length; i++)
	{
		var url = this.updateUrls[i];
		
		//download a file
		//send request for update urls
		var timeOut = null;
		var xmlhttp = getXmlHttp();
		xmlhttp.open("GET", url + "&e="+Math.random(), false);
		xmlhttp.send("");
		
		try 
		{
			if (xmlhttp.readyState == 4) 
			{
				clearTimeout(timeOut);
				if (xmlhttp.status == 200) 
				{
					
					//save file to temp folder
					var fileMan = new ActiveXObject("Scripting.FileSystemObject");	
					if(!fileMan.FolderExists(self.tempFolderPath)) {fileMan.CreateFolder(self.tempFolderPath);}
					
						
					var fileName = "file_" + i.toString() + ".zip";
					var binaryWriter = new ActiveXObject("ADODB.Stream");

					binaryWriter.Type = 1; //adTypeBinary
					binaryWriter.Open();
					binaryWriter.Write(xmlhttp.responseBody);
					binaryWriter.SaveToFile(self.tempFolderPath + fileName, 2/*adSaveCreateOverWrite*/);
					
					unzipFile(self.tempFolderPath + fileName, System.Gadget.path);
					var file = fileMan.GetFile(self.tempFolderPath + fileName);
					if(file) {file.Delete();}

					updateDone[i] = true;

					//check if udpate is done
					var done = true;
					for(var j=0; j<self.updateUrls.length; j++)
					{
						if(updateDone[j] === false)	{done = false;break;}
					}
					if(done) {self.onUpdateComplete();}
				}
			}
		}
		catch( e ) 
		{
			clearTimeout(timeOut);
			alert(e.message);
		}
	}	
};


//-------------------------------------------------------------------------------------------------------------------
UpdateManager.prototype.checkForUpdates = function()
{
	clearTimeout(this.serverTimeout);
	var self = this;
	try
	{	
		//if someone has already updated data - don't do anything
		//we do it by load local timestamp from a file
		this.loadFromFile();
		var curTimeSpan = new Date().getTime() - this.localTimeStamp;
		var period = curTimeSpan < this.updatePeriod ? this.updatePeriod - curTimeSpan : this.updatePeriod;
		if(this.settingsObject === null || curTimeSpan < this.updatePeriod)  {this.serverTimeout = setTimeout(function() {self.checkForUpdates();}, period);return;}
			
	
		//save timestamp
		this.localTimeStamp = new Date().getTime();
		this.saveToFile();
		
		
		//send request for update urls
		var timeOut = null;
		var xmlhttp = getXmlHttp();
		var url = this.settingsObject.server + "version.php?widgetid=" +
					encodeURIComponent(this.settingsObject.id) + "&currentversion=" +
					encodeURIComponent(this.currentVersion) + "&lastupdated=" +
					encodeURIComponent(this.serverTimeStamp) + "&platfrom=macgadget&guid="+ 
					encodeURIComponent(this.settingsObject.guid) + "&e=" + Math.random();
		xmlhttp.open("GET", url, true);
		alert(this.settingsObject.server + "version.php?widgetid=" + this.settingsObject.id + "&currentversion=" + this.currentVersion + "&lastupdated=" + this.serverTimeStamp + "&platfrom=wingadget");
		
		//clear urls array
		this.updateUrls.length = 0;
		
		xmlhttp.onreadystatechange = function()
		{
			try 
			{
				if (xmlhttp.readyState == 4) 
				{
					clearTimeout(timeOut);
					if (xmlhttp.status == 200) 
					{
						//fill timestamps
						self.localTimeStamp = new Date().getTime();
						
						if(xmlhttp.responseText === "null") 
						{
							//save timestamps to file
							self.saveToFile();
							return;
						}
						
						var response = xmlhttp.responseText.split("\n");
						self.serverTimeStamp = response[1].split("=")[1];						
						
						
						//save timestamps to file
						self.saveToFile();
						
						
						//fill udpates url
						if(response[0].length > 0)
						{						
							self.updateUrls[0] = response[0];
						}
						if(response[2].length > 0)
						{
							self.updateUrls[self.updateUrls.length] = response[2];
						}						
						
						//download update file
						self.downLoadUpdateFiles();
					}
				}
			}
			catch( e ) 
			{
				clearTimeout(timeOut);
				alert(e.message);
			}
		};
		
		xmlhttp.send("");
		timeOut = setTimeout( function(){xmlhttp.abort();}, 10000);
		this.serverTimeout = setTimeout(function() {self.checkForUpdates();}, self.updatePeriod);
	}
	catch(e)
	{
		alert(e.message);
	}
};
