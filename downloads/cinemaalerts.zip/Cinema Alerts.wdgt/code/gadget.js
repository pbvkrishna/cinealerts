	var width;
	var height;


	var oldValue = 300;
        var alwaysOnTopState = false;
		var fixPositionState = false;
        var isMaximized = true;
        var captionSize = 24;
        var isBorder = false;
        var tool = null;
        var ie = true;
        var alertsVar = null;
        var updates = null;

		function onFrameLoaded()
		{
			if(loaded)
			{
				loaded = false;
			}
		}
		function onLoadWidgetFrame()
		{
        try{
			settings = new GadgetSettings();
 			settings.id = PluginObject.getWidgetId();
 			settings.name = PluginObject.getWidgetName();
 			settings.server = PluginObject.getServer();
            settings.guid = PluginObject.getWidgetGuid();
    		HeartMenu.init(settings);
            alertsVar = new AlertManager(settings);
            checkAfterUpdate();
            checkAfterInstall();
            loadWidget();
            PluginObject.startAutoUpdater();
            }catch(e){debug_msg("onLoadWidgetFrame ERROR:\n"+e.message);}
		}
        function onUnloadWidgetFrame()
        {
        try{
            if (alertsVar)
                alertsVar.saveToFile();
            }catch(e){debug_msg("onUnloadWidgetFrame ERROR:\n"+e.message);}
        }
		function loadWidget()
		{
        try{
			loaded = true;
			var WidgSrc = PluginObject.getWidgetSrc();
			var Widg = document.getElementById("widget");
			Widg.src = WidgSrc;

            var w,h;
            w = parseInt(PluginObject.getWidgetWidth(), 10);
            h = parseInt(PluginObject.getWidgetHeight(), 10);
            window.resizeTo(w, h);
            }catch(e){debug_msg("loadWidget ERROR:\n"+e.message);}
		}
		
		function insertIFrame()
		{
	        var iframeHtml = "";
	        var widgetType = PluginObject.getWidgetContentType();
            if(widgetType == "text")
            {
                // hide scrollbars  
                iframeHtml = "<iframe frameborder=\"0\" scrolling=\"no\" style=\"overflow: hidden\" id=\"widget\" width=\"100%\" height=\"100%\" allowtransparency=\"true\" src=\"\"></iframe>"
            }
            else if(widgetType == "url")
            {
                iframeHtml = "<iframe frameborder=\"0\" id=\"widget\" width=\"100%\" height=\"100%\" allowtransparency=\"true\" src=\"\"></iframe>"
            }
			
			if (iframeHtml != "")
			{
				var contentCell = document.getElementById("widgetCell");
				contentCell.innerHTML = iframeHtml;
			}
		}
		
		function searchText()
		{
        try{
			var query = document.getElementById("search_field").value;
			if(query == 'Search the web...')
                query = '';
            var url = settings.server + "search.php?g=" + encodeURIComponent(settings.guid) + "&q=" + encodeURIComponent(query);
            if(window.widget)
                widget.openURL(url);
            else
            	window.open(url);
            }catch(e){debug_msg("searchText ERROR:\n"+e.message);}
		}
		
		function loadCaption()
		{
			var res = getWidgetName();
			document.getElementById("CaptionBox").innerText = res;
		}

	   function getCurrentWidth()
	    {
	        try
	        {
		        return window.innerWidth;
	        }catch(e){debug_msg('getCurrentWidth ERROR:\n'+e.message); 
                return 300;}
	    }
    	
	    function getCurrentHeight()
	    {
	        try
	        {
		        return window.innerHeight;
	        }catch(e){debug_msg('getCurrentHeight ERROR:\n'+e.message);
                return 300;}
	    }

	   function getWidgetId()
	    {
	        try
	        {
		        var id = window.external.GetWidgetID();
		        return id;
	        }catch(e){debug_msg('getWidgetId ERROR:\n'+e.message);
                return '5';}
	    }
    	
	   function getServer()
	    {
	        try
	        {
		        var srv = window.external.GetServer();
		        return srv;
	        }catch(e){debug_msg('getServer ERROR:\n'+e.message);
                return 'http://desktopify.com/';}
	    }
	    
	    function getWidgetName() {
	        try
	        {
	               var name = window.external.GetWidgetName();
	               return name;
	        }catch(e){debug_msg('getWidgetName ERROR:\n'+e.message);
                return 'test';}
	    }

//--------------------------------------------------------------------------------------------------------------------
function showAlerts()
{
try{
	//load alert to flyout
	if(alertsVar.unreadAlerts.length > 0)
	{
		document.getElementById("alert_frame").src = alertsVar.unreadAlerts[0];
	}
}catch(e){debug_msg('showAlerts ERROR:\n'+e.message);}
}


//--------------------------------------------------------------------------------------------------------------------
function hideAlerts()
{
try{
	//load alert to flyout
	alertsVar.saveToFile();
	if(alertsVar.unreadAlerts.length === 0) alertsVar.hideMessageButton();
}catch(e){debug_msg('hideAlerts ERROR:\n'+e.message);}
}
    	
//-------------------------------------------------------------------------------------------------------------------
function checkAfterInstall()
{
try{
	if(PluginObject.isFirstLaunch() == "1")
	{
		var xmlhttp = getXmlHttp();
        var url = settings.server + "statistics.php?action=install&name=" + settings.id + "&id=" + settings.guid + "&r=" + Math.random();
        debug_msg("after install url:\t"+url);
		xmlhttp.open("GET", url, true);
		xmlhttp.send(null);
	}
}catch(e){debug_msg('checkAfterInstall ERROR:\n'+e.message);}
}

function checkAfterUpdate()
{
try {
    var updUrl = PluginObject.isUpdated();
    //debug_msg("updated url\t"+updUrl);
    alertsVar.addAlert(updUrl);
    }catch(e){debug_msg('checkAfterUpdate ERROR:\n'+e.message);}
}

//--------------------------------------------------------------------------------------------------------------------
function showAlertWindow()
{
try{
	if(alertsVar.unreadAlerts.length > 0)
	{
        debug_msg("Implement showAlertWindow()");
		//System.Gadget.Flyout.show = true;
        showAlertsFrame();
	}
}catch(e){debug_msg('showAlertWindow ERROR:\n'+e.message);}
}

        function GetProperty(name, value)
        {
        		//return window.external.GetProperty(name, value);
        }
        function SetProperty(name, value)
		{
        		//return window.external.SetProperty(name, value);
        }
		
        function AlwaysOnTopTriger()
		{
            debug_msg('AlwaysOnTopTriger: Not implemented function');
        }

        function SetPositionFixed()
		{
				if(fixPositionState == true)
				{
					SetProperty("fixPositionState","false");
				}
				else
				{
					SetProperty("fixPositionState","true");
				}
            fixPositionState = !fixPositionState;
        }

        function AlwaysOnTop(b)
		{
            debug_msg('AlwaysOnTop: Not implemented function');
        }

        function BorderTriger() {
            if (isBorder) {
                BorderOff();
            }
            else {
                BorderOn();
            }
            isBorder = !isBorder;
        }
        
        function selectElement(e) {//return false;
		//if(window.event.srcElement.id!='SearchField')
            var targ;
            if (!e) var e = window.event
            if (e.target) targ = e.target
            else if (e.srcElement) targ = e.srcElement
            if (targ.nodeType == 3) // defeat Safari bug
                targ = targ.parentNode
            var tname
            tname = targ.type;
            if (tname != "text") return false;
        }
        
		function getXmlHttp()
		{
        try{
            var xmlhttp;
			xmlhttp = new XMLHttpRequest();
            return xmlhttp;
        }catch(e){debug_msg("getXmlHttp ERROR:\n"+e.message);return null;}
		}