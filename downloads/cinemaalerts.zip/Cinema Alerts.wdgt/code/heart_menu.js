HeartMenu = {
	settings: null,
	minWidth : 365,
	minHeight: 405,
	animationManager : new AnimationStack(),
	abortTimeout: null,

	init : function(settings)
	{
    try{
		this.settings = settings;

		//init parts
		HeartMenu.Sharer.init(settings);
		HeartMenu.Rater.init(settings);
		HeartMenu.Abouter.init(settings);
		HeartMenu.SendToFriender.init(settings);

		//add event handlers
		var self = this;
		document.getElementById('heart_box').onclick = function() {self.show();};
		document.getElementById('cancel_btn').onclick = function() {self.hide();};
		
		document.getElementById('show_rate_menu').onclick = function() {self.showHideSubMenu('rate_block', false, true);HeartMenu.Rater.bindSubmitBtn();};
		document.getElementById('show_share_menu').onclick = function(){self.showHideSubMenu('share_block', false, false);HeartMenu.Sharer.resetCopyBtn();};
		document.getElementById('show_send_menu').onclick = function() {self.showHideSubMenu('send_to_friend_block', false, true);HeartMenu.SendToFriender.bindSubmitBtn();HeartMenu.SendToFriender.refreshTimeStamp();};
		document.getElementById('show_about_menu').onclick = function() {self.showHideSubMenu('about_block', false, false);};

        }catch(e){debug_msg("HeartMenu::init ERROR:\n"+e.message);}
	},
	showHideSubMenu: function(id, isHiding, withSubmit)
	{
    try{
		//hide main block and show share block
		var toHideId = 'main_block';
		var toShowId = id;
		if(isHiding)
		{
			toHideId = id;
			toShowId = 'main_block';
			withSubmit = false;
			this.clearAbortTimeout();
		}

		document.getElementById(toHideId).style.filter = '';
		document.getElementById(toHideId).style.display = 'none';
		document.getElementById(toShowId).style.display = 'block';
		document.getElementById(toShowId).style.opacity = 0;

		
		document.getElementById('submit_btn').style.display = withSubmit ? 'block' : 'none';

		this.animationManager.clear();
		this.animationManager.add(new OpacityAnimationEffect(document.getElementById(toShowId), false, 200));

		this.animationManager.ready = function() {
			document.getElementById(toHideId).style.filter = '';
			document.getElementById(toHideId).style.display = 'none';
		}
		this.animationManager.start();

		var self = this;
		if(isHiding){
			document.getElementById('cancel_btn').onclick = function() {self.hide();};
		}
		else{
			document.getElementById('cancel_btn').onclick = function() {self.showHideSubMenu(id, true, false);};
		}
        }catch(e){debug_msg("HeartMenu::showHideSubMenu ERROR:\n"+e.message);}
	},
	show: function()
	{
    try{
	    if (this.settings.widgetWidth == 0)
	    {
 		    this.settings.widgetHeight = parseInt(PluginObject.getWidgetHeight(), 10);
 		    this.settings.widgetWidth = parseInt(PluginObject.getWidgetWidth(), 10);
	    }
      
        var wd;
        var hg;
        if(window.innerWidth > this.minWidth+this.settings.hBorder)
            wd = window.innerWidth;
        else
            wd = this.minWidth+this.settings.hBorder;
        if(window.innerHeight > this.minHeight+this.settings.vBorder)
            hg = window.innerHeight;
        else
            hg = this.minHeight+this.settings.vBorder;
        
		var self = this;
		document.getElementById('heart_block').style.display = 'none';
		document.getElementById('main_block').style.display = 'none';
		document.getElementById('send_to_friend_block').style.display = 'none';
		document.getElementById('about_block').style.display = 'none';
		document.getElementById('share_block').style.display = 'none';
		document.getElementById('rate_block').style.display = 'none';

		document.getElementById('cancel_btn').onclick = function() {self.hide();};
		document.getElementById('submit_btn').style.display = 'none';
		
		//hide widget to prevent flash render above content
        document.getElementById("widget").style.visibility = 'hidden';
		document.getElementById("widget").style.left = '-10000px';

		//show main block
		var mainBlock = document.getElementById('heart_block');
		mainBlock.style.width = Math.max(window.innerWidth-this.settings.hBorder, self.minWidth);
		mainBlock.style.height = Math.max(window.innerHeight-this.settings.vBorder, self.minHeight);

		mainBlock.style.display = 'block';
		mainBlock.style.position = 'absolute';
		mainBlock.style.left = '0px';
		mainBlock.style.top = '0px';
		
		document.getElementById('main_block').style.display = 'block';
		document.getElementById('main_block').style.opacity = 0;
        
		this.animationManager.clear();
		this.animationManager.add(new SizeAnimationEffect(	document.body,
								Math.max(wd, this.minWidth + this.settings.hBorder),
								Math.max(hg, this.minHeight + this.settings.vBorder)));
		this.animationManager.add(new OpacityAnimationEffect(document.getElementById('main_block'), false, 200));
		this.animationManager.start();


		
		this.animationManager.ready = function()
		{
			mainBlock.style.width = Math.max(wd-self.settings.hBorder, self.minWidth);
			mainBlock.style.height = Math.max(hg-self.settings.vBorder, self.minHeight);

			//show share block
			document.getElementById('main_block').style.filter = '';
			document.getElementById('main_block').style.display = 'block';
			
		}
        
        }catch(e){debug_msg("HeartMenu::show ERROR:\n"+e.message);}
    },

	hide: function()
	{
	try{
        var wd = this.settings.widgetWidth;
        var hg = this.settings.widgetHeight;	

		document.getElementById('heart_block').style.display = 'none';

		document.getElementById("widget").style.visibility = 'visible';

 		this.animationManager.clear();
		this.animationManager.add(new SizeAnimationEffect(	document.body,
															wd,
															hg));
		this.animationManager.start();
		var self = this;
		this.animationManager.ready = function()
		{
			document.getElementById('share_block').style.filter = '';
			//document.body.style.width = self.settings.containerWidth;
			//document.body.style.height = self.settings.containerHeight;
		}
        }catch(e){debug_msg("HeartMenu::hide ERROR:\n"+e.message);}
	}	,
	setAbortTimeout: function(xmlHttp, timeoutInSec, errorElementId)
	{
		this.clearAbortTimeout();

		//timeout 10 seconds
		this.abortTimeout = setTimeout(
		function() {
			xmlHttp.abort();
			document.getElementById(errorElementId).innerHTML = "Connection lost. Please try again";
		}, timeoutInSec*1000);
	},
	clearAbortTimeout: function()
	{
		clearTimeout(this.abortTimeout);
	}
};

HeartMenu.Sharer = {
	shareLongUrl: '',
	shareShortUrl: '',
	settings: null,

	init: function(settings)
	{
    try{
		var self=this;
		document.getElementById('share_facebook').onclick = function(){self.shareFacebook();};
		document.getElementById('share_twitter').onclick = function() {self.shareTwitter();};
		document.getElementById('share_blogger').onclick = function() {self.shareBlogger();};
		document.getElementById('share_friend_feed').onclick = function() {self.shareFriendFeed();};


		this.resetCopyBtn();
		
		this.settings = settings;
		this.shareLongUrl = settings.server + "getwidget/" + settings.name;
		this.shareShortUrl = settings.server + settings.id;
        }catch(e){debug_msg("Sharer::init ERROR:\n"+e.message);}
	},

	resetCopyBtn: function()
	{
    try{
		//reset copy button
		var btn = document.getElementById('copy_url_button');
		btn.innerHTML = "Copy widget's url";
		btn.style.cursor = "pointer";
		btn.style.textDecoration = "underline";
		btn.onclick = function() {HeartMenu.Sharer.copyUrl();}
        }catch(e){debug_msg("Sharer::resetCopyBtn ERROR:\n"+e.message);}
	},

	copyUrl: function()
	{
    try{
		if (window.widget)
		{
        var text = this.shareLongUrl;
            PluginObject.copyTextToClipboard(text);
			//window.clipboardData.setData("Text", this.shareLongUrl);
			var btn = document.getElementById('copy_url_button');
			btn.innerHTML = "Copied!";
			btn.style.cursor = "";
			btn.onclick = "";
			btn.style.textDecoration = "";
		}
        }catch(e){debug_msg("Sharer::copyUrl ERROR:\n"+e.message);}
	},

	shareBlogger: function()
	{
	try{
		var text = "Just found great desktop widget " + this.settings.name + "\nYou can download widget <a href='" +  this.shareShortUrl + "'>here</a>. The widget available for Windows and Mac";
		var url = "http://www.blogger.com/blog_this.pyra?t=" + encodeURIComponent(text) + "&u=" + this.shareShortUrl + "&n=" + encodeURIComponent("Desktop widget: " + this.settings.name);
		this.openUrl(url);
        }catch(e){debug_msg("Sharer::shareBlogger ERROR:\n"+e.message);}
	},

	shareTwitter: function()
	{
	try{
		var status = "I've found desktop widget " + this.settings.name + ", available for Windows and Mac. Download at " + this.shareShortUrl;
		var url = "http://twitter.com/home?status=" + encodeURIComponent(status);
		this.openUrl(url);
        }catch(e){debug_msg("Sharer::shareTwitter ERROR:\n"+e.message);}
	},

	shareFriendFeed: function()
	{
	try{
		var status = "I've found desktop widget " + this.settings.name + ", available for Windows and Mac. Download at " + this.shareShortUrl;
		var url = "http://friendfeed.com/?title=" + encodeURIComponent(status);
		this.openUrl(url);
        }catch(e){debug_msg("Sharer::shareFriendFeed ERROR:\n"+e.message);}
	},
	
	shareFacebook: function()
	{
	try{
		var u = encodeURIComponent(this.settings.server + "getwidget.php?widget=" + this.settings.name);
		var url = "http://www.facebook.com/sharer.php?u=" + u + "&t=" + encodeURIComponent("Desktop  widget " + this.settings.name);
		this.openUrl(url);
        }catch(e){debug_msg("Sharer::shareFacebook ERROR:\n"+e.message);}
	},

	openUrl: function(url)
	{
    try{
		widget.openURL(url);
        }catch(e){debug_msg("Sharer::openUrl ERROR:\n"+e.message);}
	}
 };


HeartMenu.Rater = {
	settings: null,
	maxRate: 5,
	currentRate: 4,
	alreadyRated: false,

	init: function(settings)
	{
    try{
		this.settings = settings;
		//add mouse handlers to stars images
		var imgs = document.getElementById('rate_stars').getElementsByTagName('img');
		var self = this;
		for(var ind=0; ind<imgs.length; ind++)
		{
			var elem = imgs[ind];

			//element events
			elem.onmouseover = function() {
				var i = 0;
				var id = this.id;
				var num = id.split("_")[1];
				//change stars
				for(i=0; i<num; i++){
					imgs[i].src = "images/star_color.png";
				}
				for(i=num; i<imgs.length; i++)	{
					imgs[i].src = "images/gray_star.png";
				}
				document.getElementById("rate_result").innerHTML = num + "/" + self.maxRate;
			}
			
			elem.onclick = function() {
				var id = this.id;
				var num = id.split("_")[1];
				document.getElementById("rate_result").innerHTML = num + "/" + self.maxRate;
				//change stars
				for(i=0; i<num; i++){
					imgs[i].src = "images/star_color.png";
				}
				for(i=num; i<imgs.length; i++){
					imgs[i].src = "images/gray_star.png";
				}
				self.currentRate = num;
			}
		}


		//show current rate
		document.getElementById('rate_stars').onmouseout = function()
		{
			for(i=0; i<self.currentRate; i++){
				imgs[i].src = "images/star_color.png";
			}
			for(i=self.currentRate; i<imgs.length; i++)	{
				imgs[i].src = "images/gray_star.png";
			}
			document.getElementById("rate_result").innerHTML = self.currentRate + "/" + self.maxRate;
		}

		if(widget.preferenceForKey("rated") == "yes")
			this.alreadyRated = true;
		}catch(e){debug_msg('HeartMenu.Rater::init ERROR:\n'+e.message);}
	},
	bindSubmitBtn: function() {
		var self = this;
		document.getElementById("submit_btn").onclick = function() { self.send(); };
		
		//clear fields
		document.getElementById("rate_feedback").value = "";
	},	
	buildRequestParams: function() {
    try{
		var params = "rate=1";
		params += "&rating=" + encodeURIComponent(this.currentRate);
		params += "&id=" + this.settings.id;

		var rateName = document.getElementById("rate_name").value;
		if(rateName.length > 0) params += "&name=" + encodeURIComponent(rateName);

		var rateFeedback = document.getElementById("rate_feedback").value;
		if(rateFeedback.length > 0)	params += "&feedback=" + encodeURIComponent(rateFeedback);
		
		return params;
        }catch(e){debug_msg('HeartMenu.Rater::init ERROR:\n'+e.message);return null;}
	},
	send: function() {
    try{
		if(this.alreadyRated) {
			document.getElementById('rate_errors').innerHTML = "You already rated this widget";
			return;
		}
		var self = this;
		var xmlHttp = getXmlHttp();
		var params = this.buildRequestParams();
		xmlHttp.open("POST", this.settings.server + "widget_endpoint.php", true);
		xmlHttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		xmlHttp.send(params);


		xmlHttp.onreadystatechange = function() {
			if(xmlHttp.readyState == 4 && xmlHttp.status == 200) {
				//close menu
				HeartMenu.showHideSubMenu("rate_block", true, false);
				self.alreadyRated = true;

                widget.setPreferenceForKey("yes", "rated");
			}
		};
        
		}catch(e){debug_alert('HeartMenu.Rater::send ERROR:\n'+e.message);}
	}
 };


HeartMenu.Abouter = {
	settings: null,
	init: function(settings)
	{
    try{
		this.setting = settings;
		document.getElementById('about_name').innerHTML = settings.name + " widget";
		document.getElementById("about_info").innerHTML = "This widget is made using<br/>desktopify platform<br/>ver. " + settings.version;
		}catch(e){debug_alert('HeartMenu.Abouter::init ERROR:\n'+e.message);}
	}
 }


HeartMenu.SendToFriender = {
	settings: null,
	serverTimeStamp: null,
	minRequestTime: 5,//5 seconds
	initTime: null,
	isSending: false,
    savedCookies: null,

	init: function(settings)
	{
    try{
		this.settings = settings;
		var text = "I've found awesome desktop widget " + settings.name + ", available for Windows and Mac. Download it at " + settings.server + settings.id;
		document.getElementById("send_feedback_textarea").innerHTML = text;
		}catch(e){debug_alert('HeartMenu.SendToFriender::init ERROR:\n'+e.message);}
	},
	bindSubmitBtn: function() {
		var self = this;
		document.getElementById("submit_btn").onclick = function() {self.send();};
		document.getElementById('send_errors').innerHTML = "";

		//clear fields
		document.getElementById("send_friend_email").value = "";

		var text = "I've found awesome desktop widget " + this.settings.name + ", available for Windows and Mac. Download it at " + settings.server + settings.id;
		document.getElementById("send_feedback_textarea").innerHTML = text;
	},
	validateForm: function() {
		var email = document.getElementById("send_email").value;
		var friendEmail = document.getElementById("send_friend_email").value;
		var err = "";

		//check all fields alre filled
		if( document.getElementById("send_name").value.length == 0 ||
		    email.length == 0 ||
			friendEmail.length == 0 ||
			document.getElementById("send_feedback_textarea").value.length == 0)
		{
			err = "Please fill all fields<br/>";
		}

		//check emails
		if(email.indexOf("@") < 0 || email.indexOf(".") < 0)
			err += "Invalid e-mail address<br/>";
		if(friendEmail.indexOf("@") < 0 || friendEmail.indexOf(".") < 0)
			err += "Invalid friend's e-mail address";

		//print error
		if(err.length > 0)
		{
			document.getElementById('send_errors').innerHTML = err;
			return false;
		}
		return true;
	},
	buildRequestParams: function() {
		var params = "send_to_friend=1";
		params += "&name=" + encodeURIComponent(document.getElementById("send_name").value);
		params += "&email=" + encodeURIComponent(document.getElementById("send_email").value);
		params += "&friend_email=" + encodeURIComponent(document.getElementById("send_friend_email").value);
		params += "&feedback=" + encodeURIComponent(document.getElementById("send_feedback_textarea").value);
		params += "&t=" + encodeURIComponent(this.serverTimeStamp);
		return params;
	},
	send: function() {
    try{
		if(this.validateForm()) {
			//one per time
			if(this.isSending || this.serverTimeStamp == "") return;
			
			var xmlHttp = getXmlHttp();

			var params = this.buildRequestParams();
			xmlHttp.open("POST", this.settings.server + "widget_endpoint.php", true);
			xmlHttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            //var currentCookie = xmlHttp.getRequestHeader("Cookie");
            //currentCookie = currentCookie + "; " + savedCookies;
            savedCookies = savedCookies.replace(/path=\/,/gi, "");
            xmlHttp.setRequestHeader("Cookie", savedCookies);
			
			var currentTime = (new Date()).getTime();
			var span = currentTime - this.initTime;
			var self = this;
			if(span > this.minRequestTime*1000)
			{
				xmlHttp.send(params);
			}
			else
			{
				//delay sending request
				setTimeout(function() {
						xmlHttp.send(params);
					},
					this.minRequestTime*1000 - span
					);
			}


			//check return code			
			this.isSending = true;
			xmlHttp.onreadystatechange = function() {
				if(xmlHttp.readyState == 4 && xmlHttp.status == 200) {
					if(xmlHttp.responseText == "1") {
						HeartMenu.showHideSubMenu("send_to_friend_block", true, false);
					}
					else {
						document.getElementById('send_errors').innerHTML = "An error occured while sending e-mail.";
					}
					self.isSending = false;
					HeartMenu.clearAbortTimeout();
				}
			}

			HeartMenu.setAbortTimeout(xmlHttp, 10, 'send_errors');
		}
		}catch(e){debug_alert('HeartMenu.SendToFriender::send ERROR:\n'+e.message);}
	},
	refreshTimeStamp : function() {
    try{
		this.serverTimeStamp = "";
		this.initTime = "";

		//request new security token from the server
		var xmlHttp = getXmlHttp();
		xmlHttp.open("GET", this.settings.server + "widget_endpoint.php?r=" + (new Date()).getTime(), true);
		xmlHttp.send(null);
		var self = this;
		xmlHttp.onreadystatechange = function() {
				if(xmlHttp.readyState == 4 && xmlHttp.status == 200) {
					self.serverTimeStamp = xmlHttp.responseText;
					self.initTime = (new Date()).getTime();
					HeartMenu.clearAbortTimeout();
                    savedCookies = xmlHttp.getResponseHeader("Set-Cookie");
				}
			}
		HeartMenu.setAbortTimeout(xmlHttp, 5, 'send_errors');
        }catch(e){};
    }
}
 