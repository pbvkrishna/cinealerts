
        
function AlertManager(settings)
{
try{
    debug_msg("init AlertManager");
	this.settingsObject = settings;
	this.unreadAlerts = new Array();
	this.timeStamp = 0;
	this.fileName = "alert.xml";
	
	this.serverTimeout = 0;
	this.blinkTimeout = 0;
	this.updatePeriod = 600000;

	this.loadFromFile();
	this.loadFromServer();	
}catch(e){debug_msg('AlertManager ERROR:\n'+e.message);}
}


//-------------------------------------------------------------------------------------------------------------------
AlertManager.prototype.loadFromFile = function()
{
try{
	//load xml document from a file
	var xmlHttp = getXmlHttp();
    
    var path =  PluginObject.loadAlertsXml();
	xmlHttp.open("GET", path, false);
    xmlHttp.send(null);
    var xmlDoc = xmlHttp.responseXML;

	if(xmlDoc) 
	{
		this.parseAlertXml(xmlDoc);
	}
}catch(e){debug_msg('AlertManager.loadFromFile ERROR:\n'+e.message);}
};


//-------------------------------------------------------------------------------------------------------------------
AlertManager.prototype.saveToFile = function()
{
try{
	//create xml output string
	var xml = "<?xml version='1.0' encoding='utf-8'?>\n<alerts timestamp='" + this.timeStamp + "'>\n";

	var i;
	for(i = 0; i < this.unreadAlerts.length; i++)
	{
		if(this.unreadAlerts[i] != null) 
		{
			xml += "<alert url='" + this.unreadAlerts[i].replace("&", "&amp;") + "'/>\n";
		}
	}
	xml += "</alerts>";
    
	//save alerts to file
	PluginObject.saveAlertsXml(xml);
}catch(e){debug_msg('AlertManager.saveToFile ERROR:\n'+e.message);}
};


//-------------------------------------------------------------------------------------------------------------------
AlertManager.prototype.addAlert = function(url)
{
try{
if(!url && typeof(url) =='undefined')
    return;
debug_msg("AlertManager.addAlert:\t"+url);

	this.unreadAlerts[this.unreadAlerts.length] = url;
    }catch(e){debug_msg('AlertManager.addAlert ERROR:\n'+e.message);}
};


//-------------------------------------------------------------------------------------------------------------------
AlertManager.prototype.removeAlert = function(index)
{
try{
	if(this.unreadAlerts.length > index) { this.unreadAlerts.splice(index, 1); }
}catch(e){debug_msg('AlertManager.removeAlert ERROR:\n'+e.message);}
};

//-------------------------------------------------------------------------------------------------------------------
AlertManager.prototype.parseAlertXml = function(xml)
{
try{
	var alerts = xml.getElementsByTagName("alerts")[0];
	//parse time stamp
	this.timeStamp = alerts.getAttribute("timestamp");
	

	if(isNaN(this.timeStamp)) 
	{
		this.timeStamp = 0; 
	}
	else
	{	
		this.timeStamp = parseInt(this.timeStamp, 10);
	}
	
	//parse alerts
	var i = 0;
	var shift = this.unreadAlerts.length;
	for(i=0; i<alerts.childNodes.length; i++)
	{
        if(alerts.childNodes[i].getAttribute)
        {
            this.addAlert(alerts.childNodes[i].getAttribute("url"));
        }
	}
	
	
	
	//set button blinking
	if(this.unreadAlerts.length > 0)
	{
		this.showMessageButton();
	}
	else
	{
		this.hideMessageButton();
	}
}catch(e){debug_msg('AlertManager.parseAlertXml ERROR:\n'+e.message);}
};

//-------------------------------------------------------------------------------------------------------------------
AlertManager.prototype.showMessageButton = function()
{
try{
    if(document.getElementById("alert_block").style.visibility == "visible")
    {
        debug_msg("alerts shown");
        return;
    }
	clearTimeout(this.blinkTimeout);
	
	//change icon on the button
	var alertIcon = document.getElementById("alert_icon");
	alertIcon.style.visibility = "visible";
	
	
	if(this.unreadAlerts.length > 0)
	{
		alertIcon.style.display = "";

		var self = this;
		this.blinkTimeout = setTimeout(function() { self.hideMessageButton(); }, 1000);		
	}
	else
	{
		alertIcon.style.display = "none";
	}
}catch(e){debug_msg('AlertManager.showMessageButton ERROR:\n'+e.message);}
};


//-------------------------------------------------------------------------------------------------------------------
AlertManager.prototype.hideMessageButton = function()
{
try{
	clearTimeout(this.blinkTimeout);
	
	//change icon on the button
	var alertIcon = document.getElementById("alert_icon");
	alertIcon.style.visibility = "hidden";
	
	if(this.unreadAlerts.length > 0)
	{
		var self = this;
		this.blinkTimeout = setTimeout(function() { self.showMessageButton(); }, 300);
	}
	else
	{
		alertIcon.style.display = "none";
	}
}catch(e){debug_msg('AlertManager.hideMessageButton ERROR:\n'+e.message);}
};

//-------------------------------------------------------------------------------------------------------------------
AlertManager.prototype.loadFromServer = function()
{
	clearTimeout(this.serverTimeout);
	var self = this;
	try
	{	
		if(this.settingsObject === null)
        {
            this.serverTimeout = setTimeout(function() { self.loadFromServer(); }, self.updatePeriod);
            return;
        }	
        
        debug_msg("AlertManager loadFromServer: this.timeStamp\t"+this.timeStamp);

		//load alet.xml from file
		var timeOut = null;
		var xmlhttp = getXmlHttp();
		xmlhttp.open("GET", this.settingsObject.server + "get_alert_list.php?name=" + this.settingsObject.id + "&time=" + this.timeStamp+"&r=" + Math.random(), true);
		debug_msg("AlertManager loadFromServer URL\t"+this.settingsObject.server + "get_alert_list.php?name=" + this.settingsObject.id + "&time=" + this.timeStamp+"&r=" + Math.random());
		xmlhttp.onreadystatechange = function()
		{
			try 
			{
				if (xmlhttp.readyState == 4) 
				{
					clearTimeout(timeOut);
					if (xmlhttp.status == 200) 
					{
                        debug_msg('xmlhttp.responseText\t'+xmlhttp.responseText);
						self.parseAlertXml(xmlhttp.responseXML);
					}
				}
			}
			catch( e ) 
			{
				clearTimeout(timeOut);
                debug_msg("AlertManager.loadFromServer.onreadystatechange ERROR:\n"+e.message);
			}
		};
		
		xmlhttp.send("");
		timeOut = setTimeout( function(){ xmlhttp.abort(); }, 10000);
		this.serverTimeout = setTimeout(function() { self.loadFromServer(); } , self.updatePeriod);
}catch(e){debug_msg('AlertManager.loadFromServer ERROR:\n'+e.message);}
};

function showAlertsFrame()
{
try{
    widget.prepareForTransition("ToBack");
    window.resizeTo(300, 300);
    setTimeout('PluginObject.setNeedsDisplay();', 750);
    
    var alertsFrame = document.getElementById("alert_block");
    alertsFrame.style.display = "block";
	alertsFrame.style.visibility = "visible";
    
    
    var mainFrame = document.getElementById("maximized_table");
	mainFrame.style.display = "none";
	mainFrame.style.visibility = "hidden";

	//init alert counter 
	var alertsObj = alertsVar;
	var alertCounter = document.getElementById("alert_counter");
	alertCounter.innerHTML = "alert: <font style=\"font: bold 12px\">" + (alertIndex + 1) + "</font>/" + alertsObj.unreadAlerts.length;
    showAlert();
    
    setTimeout('widget.performTransition();', 0);
}catch(e){debug_msg('loadAlerts ERROR:\n'+e.message);}
}

function hideAlertsFrame()
{
try{	 
    var w,h;
    w = parseInt(PluginObject.getWidgetWidth(), 10);
    h = parseInt(PluginObject.getWidgetHeight(), 10);
    //window.resizeTo(w, h);
    
    widget.prepareForTransition("ToFront");
    window.resizeTo(w, h);
    setTimeout('PluginObject.setNeedsDisplay();', 800);
 
    var alertsFrame = document.getElementById("alert_block");
    alertsFrame.style.display = "none";
	alertsFrame.style.visibility = "hidden";
    
    
    var mainFrame = document.getElementById("maximized_table");
	mainFrame.style.display = "block";
	mainFrame.style.visibility = "visible";
    
    setTimeout('widget.performTransition();', 0);
}catch(e){debug_msg('loadAlerts ERROR:\n'+e.message);}
}

//----------------------------------------------------------------------------------------------------------------------
var alertIndex = 0;
function showAlert()
{
	try
	{
		var alertsObj = alertsVar;
		var alertCounter = document.getElementById("alert_counter");
		alertCounter.innerHTML = "alert: <font style=\"font: bold 12px\">" + (alertIndex + 1) + "</font>/" + alertsObj.unreadAlerts.length;
		
		//hide window if nothing to show
		if(alertsObj.unreadAlerts.length === 0)
		{
			hideAlertsFrame();
			return;
		}
        debug_msg("alert url: "+alertsObj.unreadAlerts[alertIndex]);
		if(alertsObj.unreadAlerts.length > alertIndex)
		{
			document.getElementById("alert_frame").src = alertsObj.unreadAlerts[alertIndex];
		}		
    }catch(e){debug_msg('showAlert ERROR:\n'+e.message);}
}

//-----------------------------------------------------------------------------------------------------------------------------
function showNextAlert()
{
	try
	{
		var alertsObj = alertsVar;
		
		//scroll alert to next		
		if(alertsObj.unreadAlerts.length > alertIndex + 1) { alertIndex++; }
		showAlert();
    }catch(e){debug_msg('showNextAlert ERROR:\n'+e.message);}
}


//-----------------------------------------------------------------------------------------------------------------------------
function showPrevAlert()
{
	try
	{
		var alertsObj = alertsVar;
		
		//scroll alert to next		
		if(alertIndex > 0) { alertIndex--; }
		showAlert();
    }catch(e){debug_msg('showPrevAlert ERROR:\n'+e.message);}
}


//-----------------------------------------------------------------------------------------------------------------------------
function removeAlert()
{
	try
	{
		var alertsObj = alertsVar;
		alertsObj.removeAlert(alertIndex);
		
		if(alertsObj.unreadAlerts.length <= alertIndex) { alertIndex = alertsObj.unreadAlerts.length - 1; }
		showAlert();
    }catch(e){debug_msg('removeAlert ERROR:\n'+e.message);}
}

