function SizeAnimationEffect(elem, toWidth, toHeight, time)
{
	this.timer =  null;
	this.width = toWidth;
	this.height = toHeight;
	this.element = elem;


		if(time == null) time = 10;
//  		time /= 1000;

		var w = getCurrentWidth();
		var h = getCurrentHeight();

	//get stepW and stepH
		this.stepW = Math.abs(w - toWidth) / time;
		if (this.stepW < 1 ) {
		    this.stepW = 1;
		}
		if(w > toWidth)
			this.stepW *= -1;

		this.stepH = Math.abs(h - toHeight) / time;
		if (this.stepH < 1 ) {
		    this.stepH = 1;
		}
		if(h > toHeight)
			this.stepH *= -1;

	
	this.interval = 1,
	this.timestamp = 0;
}

SizeAnimationEffect.prototype.ready = function() {};
SizeAnimationEffect.prototype.start = function()
{
	var self = this;
//	this.timestamp = new Date().getTime();
		this.timer = setTimeout(function() {self.animateStep();}, this.interval)
}

SizeAnimationEffect.prototype.animateStep = function()
{

        var dt = 0.8;

	//perform animation step
	var widthDone = false;
	var heightDone = false;
	var w = getCurrentWidth();
	var h = getCurrentHeight();
	var newW, newH;
	if( (this.stepW > 0 && w < this.width) ||
		(this.stepW < 0 && w > this.width))
	{
		newW = w + this.stepW*dt;
	}
	else
	{
		newW = this.width;
		widthDone = true;
	}
	if( (this.stepH > 0 && h < this.height) ||
		(this.stepH < 0 && h > this.height))
	{
		newH = h + this.stepH*dt;
	}
	else
	{
		newH = this.height;
		heightDone = true;
	}
    var iW = parseInt(newW);
    var iH = parseInt(newH);
	window.resizeTo(iW, iH);

	//finished animation
	if(widthDone == true && heightDone == true)
	{
		this.ready();
	}
	else
	{
		var self = this;
		this.timer = setTimeout(function() {self.animateStep();}, this.interval)
	}
}


function OpacityAnimationEffect(elem, isReducing, time)
{
	this.timer =  null;
	this.element = elem;
	this.isReducing = isReducing;
	this.opacity = 0;

	if(time == null) time = 100;
	time /= 1000;

	if(isReducing) this.opacity = 100;

	
	//get stepW and stepH
	this.step = 100 / time;
	if(isReducing) this.step *= -1;

	this.interval = 10,
	this.timestamp = 0;
}

OpacityAnimationEffect.prototype.ready = function() {};
OpacityAnimationEffect.prototype.start = function()
{
	var self = this;
    var opa = this.opacity / 100;
	this.element.style.opacity = opa;
	this.timestamp = new Date().getTime();
	this.timer = setInterval(function() {self.animateStep();}, this.interval);
}

OpacityAnimationEffect.prototype.animateStep = function()
{
	clearInterval(this.timer);

	//update time stamp
	var stamp = new Date().getTime();
	var dt = (stamp - this.timestamp)/1000;
	this.timestamp = stamp;

	this.opacity += this.step*dt;
	var done = false;
	if(this.opacity <= 0)
	{
		this.opacity = 0;
		done = true;
	}
	if(this.opacity >= 100)
	{
		this.opacity = 100;
		done = true;
	}
    var opa = this.opacity / 100;
	//perform animation step
	this.element.style.opacity = opa;
	

	//finished animation
	if(done == true)
	{
		this.ready();
	}
	else
	{
		var self = this;
		this.timer = setInterval(function() {self.animateStep();}, this.interval)
	}
}


function AnimationStack() {
	this.effects = [];
	this.currentEffectIndex = 0;
}
AnimationStack.prototype.ready = function() {debug_msg("AnimationStack.ready");}

AnimationStack.prototype.add = function(effect) {
		this.effects[this.effects.length] = effect;
}

AnimationStack.prototype.clear = function() {
	this.effects = [];
	this.currentEffectIndex = 0;
}

AnimationStack.prototype.effectReady = function(){
try {
	var self = this;
	this.currentEffectIndex++;

	//done with effect
	if(this.currentEffectIndex == this.effects.length) {
		self.ready();
		return;
	}

	this.effects[this.currentEffectIndex].ready = function() {
		self.effectReady();
	}

	this.effects[this.currentEffectIndex].start();

} catch(e){if(DEBUGMODE)alert('AnimationStack::effectReady_ Error: '+e.message);}
}

AnimationStack.prototype.start = function () {
	var self = this;
	if(this.effects.length == 0) {
		this.ready();
	}


	//start iterating over effects
	this.effects[this.currentEffectIndex].ready = function() {
		self.effectReady();
	}

	this.effects[this.currentEffectIndex].start();
}
